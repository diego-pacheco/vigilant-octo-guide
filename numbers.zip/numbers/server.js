import express from 'express'
import cors from 'cors'
import mongoose from 'mongoose'
await mongoose.connect('mongodb://127.0.0.1:27017/numbers')
import { clasifyNumber, getNumber, getNumbers } from './functions.js'

const app = express()

app.use(express.json())
app.use(express.urlencoded({extended: true}))
app.use(cors())

// Handle errors
app.use((err, req, res, next) => {
  if (err) {
    res.status(err.status).send(err.message)
  }
  next()
  return
});

app.post('/number', async (req, res, next) => {
  try{
    res.send(await clasifyNumber(req.body.number))
    next()
  } catch(err) {
    next(err)
  }
  return
})

app.get('/number/:number', async (req, res, next) => { 
  try{
    res.send(await getNumber(req.params.number))
    next()
  } catch(err) {
    next(err)
  }
  return
})

app.get('/numbers', async (req, res, next) => {
  res.send(await getNumbers())
  next()
  return
})

app.use((err, req, res, next) => {
  if (err) {
    res.status(err.status).send(err.message)
  }
  next()
  return
});

export default app