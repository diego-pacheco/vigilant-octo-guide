import mongoose from 'mongoose'
await mongoose.connect('mongodb://127.0.0.1:27017/test-numbers')
import { clasifyNumber, getNumber, getNumbers } from './functions.js'

(async () => {
    await mongoose.connection.db.dropCollection('numbers');
})();
    
test('Testing that number 3 is catalogued as Type1', async () => {
    let numberDocument = await clasifyNumber(3)
    expect(numberDocument.type).toBe('Type1')
});

test('Testing that number 5 is catalogued as Type2', async () => {
    let numberDocument = await clasifyNumber(5)
    expect(numberDocument.type).toBe('Type2')
});

test('Testing that number 15 is catalogued as Type3', async () => {
    let numberDocument = await clasifyNumber(15)
    expect(numberDocument.type).toBe('Type3')
});

test('Testing that number 4 is catalogued as Type4', async () => {
    let numberDocument = await clasifyNumber(4)
    expect(numberDocument.type).toBe('Type4')
});

test('Testing that number 3 is found', async () => {
    let numberDocument = await getNumber(3)
    expect(numberDocument).toEqual(expect.objectContaining({ type: 'Type1', number: 3}))
});

test('Testing that number 5 is found', async () => {
    let numberDocument = await getNumber(5)
    expect(numberDocument).toEqual(expect.objectContaining({ type: 'Type2', number: 5}))
});

test('Testing that number 15 is found', async () => {
    let numberDocument = await getNumber(15)
    expect(numberDocument).toEqual(expect.objectContaining({ type: 'Type3', number: 15}))
});

test('Testing that number 4 is found', async () => {
    let numberDocument = await getNumber(4)
    expect(numberDocument).toEqual(expect.objectContaining({ type: 'Type4', number: 4}))
});

test('Testing that number 44 is not found', async () => {
    try {
        let numberDocument = await getNumber(4)
    } catch (e) {
        expect(e.message).toBe(`Number not found`)
        expect(e.status).toBe(404)
    }
});

test('Testing that number 4 was already classified/stored', async () => {
    try {
        let numberDocument = await clasifyNumber(4)
    } catch (e) {
        expect(e.message).toBe(`Number already classified`)
        expect(e.status).toBe(409)
    }
});