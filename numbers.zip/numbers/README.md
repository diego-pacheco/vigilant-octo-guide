# Numbers API

Welcome to the documentation for Numbers API. This document provides information about the endpoints, request and response formats, and usage examples.

## Overview

Numbers API is a RESTful web service that stores numbers and clasify them in 4 categories between Type1 for numbers divisible by 3, Type2 for numbers divisible by 5, Type3 for numbers divisible by both of them, and Type4 for other numbers.

## Base URL

The base URL for accessing the API is: http://localhost:3000

## Initial Setup

You need to have NodeJS v21.7.1 installed [See](https://nodejs.org/en/learn/getting-started/how-to-install-nodejs)

You need to have mongodb v7.0.2 installed and running [See](https://www.mongodb.com/docs/manual/tutorial/install-mongodb-on-os-x/)

On the root folder execute `npm install` to setup all the dependencies

To run the service execute `npm start`

Tu run the tests execute `npm test`

## Endpoints

### POST /number

- **URL**: `http://localhost:3000/number`
- **Method**: `POST`
- **Content-Type**: `application/json`

## Request Body

- **Type**: JSON Object
- **Fields**:
  - `number` (required): The number to be classified and store.

**Request Example:**

```json
{
    "number": 3
}
```

**Response Example:**

```json
{
    "_id": "660eb8a956b354d4ff2a3d67",
    "number": 3,
    "__v": 0,
    "type": "Type1"
}
```

### GET /number/:number

- **URL**: `http://localhost:3000/number/:number`
- **Method**: `GET`
- **Content-Type**: `application/json`

**Response Example:**

```json
{
    "_id": "660eb8a956b354d4ff2a3d67",
    "number": 3,
    "__v": 0,
    "type": "Type1"
}
```

### GET /numbers

- **URL**: `http://localhost:3000/numbers`
- **Method**: `GET`
- **Content-Type**: `application/json`

***Response Example***

```json
[
    {
        "_id": "660eb8a956b354d4ff2a3d67",
        "number": 3,
        "__v": 0,
        "type": "Type1"
    },
    {
        "_id": "660eb96256b354d4ff2a3dba",
        "number": 5,
        "__v": 0,
        "type": "Type2"
    },
    {
        "_id": "660eb96656b354d4ff2a3dbd",
        "number": 15,
        "__v": 0,
        "type": "Type3"
    },
    {
        "_id": "660eb96b56b354d4ff2a3dc2",
        "number": 4,
        "__v": 0,
        "type": "Type4"
    },
    {
        "_id": "660ebaac56b354d4ff2a3e50",
        "number": 2,
        "__v": 0,
        "type": "Type4"
    },
    {
        "_id": "660ec86356b354d4ff2a42de",
        "number": 150,
        "__v": 0,
        "type": "Type3"
    },
    {
        "_id": "660ec86c56b354d4ff2a42e1",
        "number": 55,
        "__v": 0,
        "type": "Type2"
    },
    {
        "_id": "660ec87456b354d4ff2a42e7",
        "number": 88,
        "__v": 0,
        "type": "Type4"
    },
    {
        "_id": "660ec87a56b354d4ff2a42ec",
        "number": 40,
        "__v": 0,
        "type": "Type2"
    },
    {
        "_id": "660ed95056b354d4ff2a49a8",
        "number": null,
        "__v": 0,
        "type": "Type4"
    },
    {
        "_id": "660f122156b354d4ff2a5766",
        "number": 1,
        "__v": 0,
        "type": "Type4"
    }
]```
