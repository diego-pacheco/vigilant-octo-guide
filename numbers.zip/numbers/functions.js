import mongoose from 'mongoose'

const schema = new mongoose.Schema({
    number: Number,
    type: {
        type: String,
        enum : ['Type1','Type2','Type3', 'Type4'],
        default: 'Type4'
    },
})

const NumberSchema = mongoose.model('Number', schema)

export const clasifyNumber  = async (number) => {

    //let type = "Type4"
    //let divisibleBy3 = number%3 === 0
    //let divisibleBy5 = number%5 === 0
    //console.log(divisibleBy3)
    //console.log(divisibleBy5)
    //type = divisibleBy3? 'Type1': type
    //type = divisibleBy5? 'Type2': type
    //type = divisibleBy3 && divisibleBy5? 'Type3': type;

    let numberDocument = await NumberSchema.findOne({ number: number })
    if(numberDocument){
        let error = new Error(`Number already classified`)
        error.status = 409
        throw error
    }

    let type = 'Type4',
        divisibleBy3 = false,
        divisibleBy5 = false

    if(number%3 === 0){ 
        type = 'Type1'
        divisibleBy3 = true
    }

    if(number%5 === 0){
        type = 'Type2'
        divisibleBy5 = true
    }

    if(divisibleBy3 && divisibleBy5) type = 'Type3'

    return await NumberSchema.findOneAndUpdate({ number: number }, { type: type }, {
        new: true,
        upsert: true // Making this trade off just to avoid checking if number was already stored and clasified
      });

}

export const getNumber = async (number) => {
    let numberDocument = await NumberSchema.findOne({ number: number})

    if(!numberDocument){
        let error = new Error(`Number not found`)
        error.status = 404
        throw error
    }

    return numberDocument;
}

export const getNumbers = async () => {
    return await NumberSchema.find()
}